"""Render the continuous-boundary comparison and replay seal sensitivities.

Search inputs/results live in results/fair_closure. This command does not rerun
or claim a global architecture optimization.
"""
from dataclasses import replace
import json
import math
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt
from ..system import inputs_from_dict
from ..door_trade import FlowCapabilities, DoorControls, simulate_trade

ROOT = Path('results/fair_closure')
LABELS = {'comparison':'100 × 2,000 km comparison', 'candidate':'90 × 937 km geometry',
          'weak_support':'Comparison, support 0.6 ρu²', 'high_floor':'Comparison, 1 Pa pump limit',
          'capacity_limited':'450 m front, fixed half-capacity pumps'}


def main():
    cases = {name:json.loads((ROOT/f'{name}.json').read_text()) for name in LABELS}
    limited = cases['capacity_limited']; closed = limited['cases']['closed']
    controls = DoorControls(**closed['controls']); inputs = inputs_from_dict(closed['inputs'])
    cap = FlowCapabilities(**closed['flow_capabilities'])
    seals = []
    for fraction in (0., 1e-5, 1e-4, 1e-3, 1e-2):
        result = simulate_trade(inputs, replace(cap, closed_leak_area_fraction=fraction), controls, n=3201)
        seals.append({'seal_area_fraction':fraction,'result':result})
    Path('results/mouth_closure.json').write_text(json.dumps(dict(
        status='Conditional model comparison, not validated leakage prediction',
        search_results={k:str(ROOT/f'{k}.json') for k in cases},
        seal_sensitivity=seals),indent=2,allow_nan=False)+'\n')
    plt.rcParams.update({'svg.fonttype':'none','font.size':10})
    fig, axs = plt.subplots(3,2,figsize=(13,10),layout='constrained')
    for column,name in enumerate(('comparison','capacity_limited')):
        r=cases[name]
        for kind,col in (('open','#087e8b'),('closed','#d06a24')):
            h=r['cases'][kind]['history']; t=np.array(h['time_s'])
            axs[0,column].semilogy(t,h['front_Pa'],color=col,label='No door' if kind=='open' else 'Door fitted')
            axs[1,column].plot(t,h['pump_kg_s'],color=col,label=kind)
            axs[2,column].plot(t,1000*np.array(h['leaked_kg']),color=col)
        h=max((c['history'] for c in r['cases'].values()),key=lambda h:h['time_s'][-1])
        axs[0,column].semilogy(h['time_s'],h['support_Pa'],'--',color='#777777',label='Assumed support κρu²')
        cutoff=r['cases']['closed']['controls']['cutoff_Pa']
        axs[0,column].axhline(cutoff,color='#b34479',ls=':',label=f'Cutoff ≈ {cutoff:.3g} Pa')
        a=r['cases']['closed']
        if a['outputs']['door_fully_closed_before_stop']:
            for ax in axs[:,column]:
                ax.axvspan(a['controls']['closure_time_s'],a['controls']['closure_time_s']+cap.closure_duration_s,color='#d06a24',alpha=.15)
        for kind,col in (('open','#087e8b'),('closed','#d06a24')):
            stop=r['cases'][kind]['outputs']['cycle']['recovery_s']
            for ax in axs[:,column]: ax.axvline(stop,color=col,ls=':',alpha=.6)
        for ax in axs[:,column]:
            ax.grid(alpha=.2); ax.set_xlim((-420,400) if column==0 else (110,240))
        axs[0,column].set_ylim((.02,80) if column==0 else (.8,12))
        if column==1: axs[1,column].set_ylim(0,.25)
        axs[0,column].set_title('100 × 2,000 km: freely sized pumps' if column==0 else 'Capacity-limited diagnostic: outbound detail')
        axs[0,column].legend(fontsize=8,loc='upper right')
        axs[2,column].set_xlabel('Seconds from perigee')
    axs[0,0].set_ylabel('Front pressure (Pa)');axs[1,0].set_ylabel('Useful compressor flow (kg/s)')
    axs[2,0].set_ylabel('Cumulative reverse leakage (grams)')
    axs[2,1].text(.03,.94,'Shaded band: 5 s closure\nDotted vertical lines: pump stops',transform=axs[2,1].transAxes,va='top',fontsize=9)
    fig.suptitle('Mouth closure: common intake physics, different control policies\nReduced port and pump envelope; shock position is not calculated',fontsize=14)
    Path('figures').mkdir(exist_ok=True)
    fig.savefig('figures/mouth_closure.png',dpi=160);fig.savefig('figures/mouth_closure.svg');plt.close(fig)
    lines=['# Mouth closure: a controlled comparison','',
    '**The freely sized cases favor removing the closure. A deliberately pump-limited case gives a small conditional benefit to keeping it.** These are operating-orbit payoff results from a common continuous inlet law. Actual scoop leakage and compressor performance remain unvalidated; the small positive door result is especially sensitive to those assumptions.','',
    'The inlet and compressor wall remain. “No door” removes only the pressure-retaining closure, its supports, seals and actuation allowance. Rear storage is isolated when pumping ends.','',
    '## Equal treatment of both options','',
    'Both start with an empty front chamber at inbound 200 km and use the same bidirectional boundary throughout the encounter. Both can collect after perigee. Each branch searches installed suction capacity and commanded cutoff; the door branch also searches closure time and may leave the door unused. Both pay for all dependent hardware, electrical energy and heat rejection. Closing at perigee is not imposed.','',
    'Geometry, orbit, gas temperature, staging and technology assumptions are held fixed within each pair. This is a bounded control/capacity search, **not a whole-vehicle or global optimum**. Suction multipliers span 0.5–1.5, cutoff spans 1.05 times effective ultimate pressure to at least 10 Pa, and closure commands span 0–900 s after perigee. A paired coarse grid and two bounded coordinate passes are followed by cross-seeding controls and 1,601/3,201-sample replays. The capacity-limited diagnostic fixes suction at 0.5.','',
    '## Results','',
    '| Fixed design / capability scenario | No-door payoff | Door payoff | Door command before pump stops? | Break-even door hardware |',
    '|---|---:|---:|---|---:|']
    for name,r in cases.items():
        a=r['cases']['open']['outputs'];b=r['cases']['closed']['outputs']
        threshold=r['door_hardware_break_even_kg']
        threshold_text='≈ 0 (numerical/search tolerance)' if abs(threshold)<5 else f'{threshold:,.0f} kg'
        lines.append(f"| {LABELS[name]} | {a['operating_mass_payoff_days']:,.2f} d | {b['operating_mass_payoff_days']:,.2f} d | {'Yes' if b['door_fully_closed_before_stop'] else 'No; door unused'} | {threshold_text} |")
    lines += ['',
    'The first four cases use **4,000 s Isp**. The 90 km case borrows the saved search geometry (25 m front, 26.52 m rear, 30 m mouth), but changes its Isp to 4,000 s and uses this continuous encounter. It is not a replay of the earlier 3,322 s optimization. The other comparison geometry has an 18.3 m mouth and bore, 250 m front and 25 m rear. The diagnostic instead uses a 450 m front and 5,500 s Isp so its reduced capture still passes the oxygen-only propellant screen. It is a different scenario, not an improvement over the comparison craft.','',
    'In the freely sized cases, the fitted door is best left open until useful pumping has ended. Its extra mass buys essentially no recovered gas. At the configured 10 kg/m², hardware mass is 2.63 t for the 18.3 m mouth or 7.07 t for the 30 m mouth, plus the shared 25% dry-mass margin. Small signed break-even values near zero reflect search/integration tolerances, not a physical negative door mass.','',
    '### Complete paired budgets','',
    '| Case / option | Admitted | Stored | Reverse leak | Final front vent | Dry mass | Net liquid / day | Compressor mass |',
    '|---|---:|---:|---:|---:|---:|---:|---:|']
    for name in ('comparison','candidate','capacity_limited'):
        for kind,c in cases[name]['cases'].items():
            o=c['outputs']
            lines.append(f"| {LABELS[name]} / {kind} | {o['captured_kg']:,.3f} kg | {o['retained_kg']:,.3f} kg | {o['mouth_leakage_kg']:.6f} kg | {o['final_front_vent_kg']:.6f} kg | {o['total_dry_kg']/1000:,.2f} t | {o['net_liquid_equivalent_kg_day']:,.2f} kg | {o['compressor_mass_kg']/1000:,.2f} t |")
    lines += ['', 'Stored mass is before oxygen propulsion and processing losses; daily net liquid is after them. All listed cases pass the implemented screens. Zero predicted reverse flow does not imply zero spillage: rejected intake is distinct from gas that entered and then escaped. Gas still in the front at cutoff is counted as lost, even with a door, because the mouth must reopen for sheet deployment.','',
    '| Case / option | Rated hot suction | Cutoff | Pump stops after perigee | Closure command | Solar area | Warm radiator panels | Metal sheets |',
    '|---|---:|---:|---:|---:|---:|---:|---:|']
    for name in ('comparison','candidate','capacity_limited'):
        for kind,c in cases[name]['cases'].items():
            o=c['outputs'];ctl=c['controls'];close=f"{ctl['closure_time_s']:.1f} s" if kind=='closed' and o['door_fully_closed_before_stop'] else 'unused'
            lines.append(f"| {LABELS[name]} / {kind} | {o['hot_suction_m3_s']:,.0f} m³/s | {ctl['cutoff_Pa']:.4f} Pa | {o['cycle']['recovery_s']:.1f} s | {close} | {o['solar_area_m2']:,.0f} m² | {o['warm_radiator_panel_m2']:,.0f} m² | {o['metal_panel_m2']:,.0f} m² |")
    lines += ['', 'Radiator and sheet areas are physical panel areas, with two emitting faces. Solar area is collecting area. The comparison orbit takes 106.19 minutes; the 90 km geometry’s orbit takes 94.90 minutes.','',
    '## When can the door help?','',
    'The capacity-limited diagnostic has more front inventory relative to installed pumping. Its best door command is about +159.7 s, taking 5 s to close. It then pumps to +217.5 s; the open craft reaches its cutoff at +187.9 s. The door saves about **0.146 kg per pass** from reverse leakage, while both leave about 0.433 kg at the 1.05 Pa cutoff. It improves payoff by only **0.207 day (about five hours) on a roughly 1,860-day payoff**.','',
    'For these fixed policies, the door hardware breaks even at about **2.89 t, or 10.98 kg/m² of mouth** before margin. The assumed door is 10 kg/m². A roughly 10% increase in door allowance erases the benefit. Allowing larger pumps is another competing design response; this example is not evidence that a capacity-limited craft should be selected. The cutoff reaches the imposed 1.05-times-ultimate lower search bound, so the result is conditional on that operating margin too.','',
    '### Seal sensitivity, same diagnostic controls','',
    'These are fixed-policy replays; the closure time and pumps are not reoptimized for each seal. The equivalent leak aperture is a fraction of mouth area, not an estimate of a real seal gap.','',
    '| Equivalent seal area / mouth | Reverse leak | Pump stop | Door payoff | Difference from no door | Screens |',
    '|---|---:|---:|---:|---:|---|']
    open_days=limited['cases']['open']['outputs']['operating_mass_payoff_days']
    for s in seals:
        r=s['result'];o=r['outputs'];days=o['operating_mass_payoff_days']
        lines.append(f"| {s['seal_area_fraction']:.0e} | {o['mouth_leakage_kg']:.6f} kg | +{o['cycle']['recovery_s']:.1f} s | {days:.3f} d | {days-open_days:+.3f} d | {'pass' if r['constraints']['all_implemented_screens_pass'] else 'FAIL'} |")
    lines += ['', '![Pressure, useful pumping and leakage for both architectures](../../figures/mouth_closure.svg)','',
    'The comparison curves nearly coincide: the fitted door is unused. The diagnostic zoom shows why sealing can help: falling external support allows reverse flow while the open compressor is still recovering gas. Closing suppresses that path, but useful pump speed continues falling toward its ultimate pressure. The chart shows pressure, not the position of a shock.','',
    '## Implemented flow and cutoff equations','',
    'For front volume V at prescribed cooled temperature T:', '',
    '```text\np_front = M_front R T / V\np_support = κ ρ∞ u²\ndM_front/dt = admission − reverse leakage − useful pump flow\ndM_rear/dt = useful pump flow\np_ultimate = max(capability floor, intermediate pressure / maximum compression)\nuseful pump flow = S_rated × max(p_front − p_ultimate, 0) / (R T)\n```','',
    'Admission is the smaller of geometric interception and ideal compressible-port flow from support to front pressure. Reverse leakage uses that same port in the opposite direction, including choking. A closing door reduces its effective area continuously; a finite seal aperture remains. The nominal support is ρu² (twice dynamic pressure q), discharge factor 0.8, closure duration 5 s and closed leak area 10⁻⁵ of mouth area. These are declared scenarios, not measured scoop coefficients. Optional support-response lag is available but uncalibrated and zero here.','',
    'The finite-backflow pump envelope has S_effective/S_rated = max(1 − p_ultimate/p, 0). Effective ultimate pressure is 0.03 Pa nominally, with a maximum hot-train compression ratio of 10⁶. Useful pumping therefore approaches zero continuously; it is not constant suction abruptly switched off at a magic pressure. Internal backflow compression work and a 5% reference-power idle allowance remain charged while enabled. The commanded cutoff must be strictly above ultimate pressure, and stops pumping on the outbound downward crossing. A 1,200 s timeout is a failed completion screen, not a successful recovery. Rear check/isolation valves prevent pump-mediated tank reflux.','',
    'This envelope is motivated by finite internal leakage in vacuum pumps, but it is **not a measured pump map** at the required temperature, size or gas composition. Constant efficiency and the compressor mass coefficients remain development targets. Suction scale sizes installed hardware; it is not free control authority. The primary pressure target only defines the reference suction scale in this experiment; actual admission is then calculated.','',
    '### Heat, momentum and fair accounting','',
    '- Integrated admitted gas, rear inventory, outward leakage and final residual satisfy mass conservation. Oxygen is transported separately. Incoming enthalpy, compression work, stored energy and escaping-gas enthalpy close the thermal ledger. Peak aftercooler duty sizes the shared exchanger allowance.','- Captured gas incurs its encounter impulse even if it later leaks. Upstream escape adds a conditional nozzle-recoil estimate. Rejected air and the closed face are also charged: the nominal scenario transfers one incident momentum flux over the projected mouth area throughout the atmospheric window. Closing a door cannot make intercepted air disappear from the propulsion budget.','- This projected-mouth drag scenario does not resolve hull/fins, skin friction, unstart spillage direction or actual closed-door forces. Additional post-cutoff heat deposition and door-specific thermal protection are unresolved. Both hardware budgets are conditional on the same omissions.','',
    'The physical reasons for differences from the general requirement-model outputs are the common inbound/outbound boundary, start at 200 km, finite-backflow/idle pump penalties, rejected/blocked-air momentum and peak aftercooler sizing. The earlier prescribed-inbound, perigee-closure calculation must not be used as an architecture verdict.','',
    '## Numerical verification versus physical accuracy','',
    'All winners were replayed at 1,601 and 3,201 environmental samples with adaptive LSODA integration. Maximum relative change across admitted mass, stored mass, dry mass and compressor energy is '+f"{max(v for r in cases.values() for branch in r['verification'].values() for v in branch.values()):.2e}"+'. Tests cover identical pre-closure behavior, an unused door changing only mass, finite-backflow analytic pumpdown, finite seal leakage, conservation, sonic port limits, cutoff rejection and timeouts. This establishes numerical consistency within the assumed model.','',
    '**Accurate expected leakage still requires offline inlet and compressor calibration.** The reduced port does not locate the shock, predict start/unstart hysteresis, resolve the cooler pressure drop, or establish an effective reverse-flow area. The conditional decision is therefore: removing the door is favored across the freely sized scenarios tested; a sufficiently light, well-sealed door can help when pumping capacity is constrained, but the demonstrated gain is smaller than unresolved engineering uncertainty.','',
    '## Run and modify','',
    '```sh\n# Paired control/capacity searches (several minutes each)\n.venv/bin/python -m atmo_scoops.studies.fair_closure --case all\n# Report, seal sensitivity and figures from saved searches\nMPLCONFIGDIR=/tmp/atmo-scoops-mpl .venv/bin/python -m atmo_scoops.studies.mouth_closure\n```','',
    '```python\nimport json\nfrom pathlib import Path\nfrom dataclasses import replace\nfrom atmo_scoops.system import inputs_from_dict\nfrom atmo_scoops.door_trade import simulate_trade, FlowCapabilities, DoorControls\n\ninputs = inputs_from_dict(json.loads(Path("configs/reference.json").read_text()))\ninputs["design"] = replace(inputs["design"], mouth_closure=False)\nresult = simulate_trade(inputs, FlowCapabilities(ultimate_inlet_Pa=0.03),\n                        DoorControls(cutoff_Pa=0.1, suction_scale=0.8),\n                        n=1601, history=True)\n```','',
    'Full resolved inputs, inactive legacy controls, coefficients, histories, screens and search traces are in [results/fair_closure](../../results/fair_closure/). Seal replays are in [results/mouth_closure.json](../../results/mouth_closure.json). The implementation is [door_trade.py](../../atmo_scoops/door_trade.py); it shares downstream plant and mass equations with the primary model. It is not yet substituted into the 19-variable geometry optimizer.','',
    'Sources: [NASA compressible mass flow](https://www.grc.nasa.gov/www/BGH/mflchk.html), [Pfeiffer vacuum-generation principles](https://www.pfeiffervacuum.com/no/en/knowledge/vacuum-technology/knowledge-book/4-vacuum-generation/), and [Leybold Fundamentals of Vacuum Technology](https://www.leybold.com/content/dam/brands/leybold/downloads/brochures/general-brochures/Fundamentals_of_Vacuum_Technology_EN.pdf). These support limiting relationships, not the selected scoop coefficients. See [source qualifications](../../docs/SOURCES.md), [remaining model work](../../docs/MODEL_IMPROVEMENTS.md) and the [offline fluid study](../fluid/README.md).','']
    Path('analysis/primary/MOUTH_CLOSURE.md').write_text('\n'.join(lines))
    print('Wrote current closure report, sensitivity data and figures.')

if __name__=='__main__':
    main()
