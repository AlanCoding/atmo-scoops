"""Paired, bounded pump-capacity/cutoff/closure-policy search (conditional)."""
from dataclasses import replace,asdict
import json
from pathlib import Path
import argparse
import math
import numpy as np
from scipy.optimize import minimize_scalar
from ..system import inputs_from_dict
from ..door_trade import FlowCapabilities,DoorControls,simulate_trade

ROOT=Path('results/fair_closure')


def run_case(name,inputs,cap,scales=(.5,.75,1.,1.25,1.5),fixed_scale=None):
    ROOT.mkdir(parents=True,exist_ok=True)
    floor=max(cap.ultimate_inlet_Pa,inputs['design'].intermediate_Pa/cap.hot_train_max_compression)
    lower=1.05*floor;upper=max(10.,3*floor)
    cutoffs=sorted(set((lower,max(.1,lower),max(1.,lower),upper)))
    cache={};trace=[];best={False:None,True:None}
    def evaluate(closed,S,p,t=0.):
        key=(closed,round(float(S),7),round(float(p),7),round(float(t),5))
        if key in cache:return cache[key]
        ctl=DoorControls(closure_time_s=float(t),cutoff_Pa=float(p),suction_scale=float(S))
        inp={**inputs,'design':replace(inputs['design'],mouth_closure=closed)}
        try:
            r=simulate_trade(inp,cap,ctl,n=201)
            feasible=r['constraints']['all_implemented_screens_pass']
            score=r['outputs']['operating_mass_payoff_days'] if feasible else 1e9
            if feasible and (best[closed] is None or score<best[closed]['outputs']['operating_mass_payoff_days']):best[closed]=r
        except (ValueError,RuntimeError,ZeroDivisionError) as exc:
            r={'error':str(exc)};score=1e9
        cache[key]=(score,r)
        trace.append(dict(closure=closed,suction_scale=S,cutoff_Pa=p,closure_time_s=t,
                          payoff_days=score if score<1e9 else None))
        if len(trace)%25==0:
            summary={str(k):None if v is None else v['outputs']['operating_mass_payoff_days'] for k,v in best.items()}
            print(name,len(trace),summary,flush=True)
            (ROOT/f'{name}_progress.json').write_text(json.dumps(dict(best_days=summary,trace=trace),indent=2)+'\n')
        return score,r
    if fixed_scale is not None:scales=(fixed_scale,)
    for S in scales:
        for p in cutoffs:
            _,r=evaluate(False,S,p)
            if 'error' in r:continue
            stop=r['outputs']['cycle']['recovery_s']
            for t in (0.,.3*stop,.6*stop,.85*stop,stop+10.):evaluate(True,S,p,t)
    # Local coordinate refinements are explicitly bounded and repeatable, not
    # a global-optimum claim. Both architecture branches get equal cutoff and
    # installed-capacity freedom; only the fitted door has a closure-time control.
    for closed in (False,True):
        if best[closed] is None:continue
        for _ in range(2):
            for key in (['suction_scale'] if fixed_scale is None else [])+['cutoff_Pa']+(['closure_time_s'] if closed else []):
                b=best[closed]['controls'];lo,hi={'suction_scale':(.5,1.5),'cutoff_Pa':(math.log(lower),math.log(upper)),'closure_time_s':(0.,900.)}[key]
                def objective(z):
                    c=dict(b);c[key]=math.exp(z) if key=='cutoff_Pa' else z
                    return evaluate(closed,c['suction_scale'],c['cutoff_Pa'],c['closure_time_s'])[0]
                rr=minimize_scalar(objective,bounds=(lo,hi),method='bounded',options=dict(maxiter=14,xatol=.001))
                objective(lo);objective(hi);objective(rr.x)
    # Cross-seed the final controls so a local-search discrepancy cannot be
    # mistaken for a benefit of the architecture. A fitted door may remain open.
    if best[False] is not None:
        b=best[False];c=b['controls']
        evaluate(True,c['suction_scale'],c['cutoff_Pa'],min(900.,b['outputs']['cycle']['recovery_s']+10))
    if best[True] is not None:
        c=best[True]['controls'];evaluate(False,c['suction_scale'],c['cutoff_Pa'])
    verified={};audit={}
    for closed in (False,True):
        if best[closed] is None:continue
        c=DoorControls(**best[closed]['controls']);inp={**inputs,'design':replace(inputs['design'],mouth_closure=closed)}
        a=simulate_trade(inp,cap,c,n=1601);b=simulate_trade(inp,cap,c,n=3201,history=True)
        err={k:abs(a['outputs'][k]/b['outputs'][k]-1) for k in ('captured_kg','retained_kg','total_dry_kg','compressor_kWh')}
        assert max(err.values())<3e-4,err
        assert b['constraints']['all_implemented_screens_pass'],b['constraints']
        assert abs(b['outputs']['thermal_energy_balance_residual_J'])<.01
        verified['closed' if closed else 'open']=b;audit['closed' if closed else 'open']=err
    # Remove door+allocated margin only; compare net production and all other
    # hardware with the independently searched open architecture.
    threshold=None
    if len(verified)==2:
        a=verified['open']['outputs'];b=verified['closed']['outputs'];margin=1+inputs['hardware'].design_margin
        B=b['total_dry_kg']-margin*b['masses_kg']['mouth_closure']
        threshold=(a['operating_mass_payoff_days']*b['net_liquid_equivalent_kg_day']-B)/margin
    result=dict(name=name,scope='Fixed geometry/orbit/technology; searched installed suction capacity, cutoff, and optional closure time',
        search=dict(suction_scale=[.5,1.5] if fixed_scale is None else [fixed_scale,fixed_scale],
            cutoff_Pa=[lower,upper],closure_time_s=[0,900],method='coarse paired grid + two bounded coordinate passes',
            evaluations=len(trace),initial_samples=201,verification_samples=[1601,3201],global_optimum_claim=False),
        cases=verified,door_hardware_break_even_kg=threshold,verification=audit,trace=trace)
    (ROOT/f'{name}.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
    print('FINISHED',name,{k:v['outputs']['operating_mass_payoff_days'] for k,v in verified.items()},'door break-even kg',threshold,flush=True)
    return result


def main():
    p=argparse.ArgumentParser();p.add_argument('--case',choices=['comparison','candidate','weak_support','high_floor','capacity_limited','all'],default='all');a=p.parse_args()
    base=inputs_from_dict(json.loads(Path('configs/reference.json').read_text()))
    candidate=inputs_from_dict(json.loads(Path('results/optimization/free_orbit_config.json').read_text()))
    candidate['design']=replace(candidate['design'],isp_s=4000.)
    limited={**base,'design':replace(base['design'],front_depth_m=450,isp_s=5500.)}
    cases=[('comparison',base,FlowCapabilities(),None),('candidate',candidate,FlowCapabilities(),None),
        ('weak_support',base,FlowCapabilities(support_over_ram=.6),None),
        ('high_floor',base,FlowCapabilities(ultimate_inlet_Pa=1.),None),
        ('capacity_limited',limited,FlowCapabilities(ultimate_inlet_Pa=1.),.5)]
    for name,inp,cap,fixed in cases:
        if a.case in (name,'all'):run_case(name,inp,cap,fixed_scale=fixed)

if __name__=='__main__':main()
