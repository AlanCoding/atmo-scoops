# Working in atmo-scoops

This standalone Python research project implements one two-compartment scoop
architecture. Use the local `.venv`; do not initialize Git unless requested.
Do not modify the adjacent website or orbital-shape-sim without authorization.

Read README.md, analysis/primary/MODEL.md and analysis/primary/PARAMETERS.md before changing physics.

## Agreed system

- Mouth, shock/diffuser, solid metal precooling rack in the front compartment,
  compressor wall, separate rear gas storage, then coast liquefaction.
- Mouth closure is optional. For architecture comparisons use
  `door_trade.simulate_trade`: both options collect inbound and outbound with
  the same continuous boundary; choose closure time, installed suction and
  commanded cutoff above finite-backflow ultimate pressure. Include seal
  leakage and closure duration; fail timed-out recovery. Isolate rear storage
  and deploy attached sheets through the open mouth.
- Solar arrays and separate warm ammonia-loop radiators deploy in coast.
- Battery-powered oxygen propulsion operates near perigee. Isp comparison is
  4,000 s. Capture-only impulse is a floor; hull/closed-door drag is unresolved.
- Count all useful cryogenic product. Ultimate payoff ends in a circular orbit
  at apogee, with delivery/circularization costs. Current outputs are operating
  orbit production, not delivered payoff. Keep this distinction explicit.
- Required dry mass is an output, with no upper ceiling. Keep hardware, working
  fluids, consumed propellant and product distinct.

## Inputs and reporting

- Use physical front/rear depths in metres. Rear depth includes rounded heads.
  Default mouth and both clear bores are 18.3 m, but independently configurable.
- The 250 m front depth is only a reproducibility coordinate. It was not selected
  by an optimizer and must not be highlighted as preferable to shorter rows.
- `system.simulate` is the public API; `python -m atmo_scoops` is the current CLI.
  `configs/reference.json` is a complete editable input file, not an optimum.
- Separate design variables from environmental assumptions and hardware
  capability targets. Serialize all choices. Do not optimize technology into
  better performance without saying so.
- Metal hot endpoint = compressor inlet temperature - gas/metal approach.
  Enforce cold < hot and the implemented material-property range. A hotter
  passive sink cannot provide a colder gas outlet for free.
- Prescribed full inbound capture, uniform front temperature and equivalent compressor efficiency
  are conditional requirements. Pressure target is not a shock stability law.
- Gas conductance, pressure loss, actual capture, pump maps, structural loads,
  repeatable mechanisms and finite-thrust delivery remain unresolved.
- Compressor mass and propulsion specific mass are explicit development targets,
  not measured spacecraft capabilities. No rotor speed or mechanism is selected.
- Distinguish physical sheet area from two-face emitting area. Material,
  deployment and radiator mass must not be counted twice.
- Keep docs and entry points focused on this architecture. Do not restore
  superseded designs, contradictory instructions or outdated payoff claims.
- Current search: atmo_scoops/optimization/{search,review,report}.py
  and analysis/optimization/RESULTS.md. Closed-mouth searches use 17 coordinates
  at fixed orbit or 19 with orbit adjustable; open-mouth searches omit the
  inactive residual-fraction coordinate. Capabilities remain fixed. Objective is OPERATING-ORBIT mass
  payoff, not circular-delivery payoff. Keep bounds, near-zero oxygen margins,
  missing exchanger/shock/packing constraints and finite-thrust limitations
  explicit. Saved winning inputs live in results/optimization/*_config.json;
  do not silently replace configs/reference.json. Some DE runs reach their
  generation limit; seed agreement is not a global-optimum certificate.
- Inbound front inventory uses the exact interval solution for linearly interpolated
  inflow at constant suction. Preserve its independent adaptive-ODE comparison
  tests when changing that performance-critical numerical routine.

## Validation

- Run `.venv/bin/python -m pytest -q` and `.venv/bin/python -m atmo_scoops.audit`.
- Regenerate affected results, reports and figures from code; do not edit
  generated numerical tables manually.
- Cite primary research/property sources in docs/SOURCES.md. Preserve the
  distinction between calculation, evidence, screening assumptions and targets.

## Repository purpose and analysis boundaries

- Maintain docs/DESIGN.md as the single current design description. Update it
  in place; do not write a blog of incremental or superseded designs.
- Track unresolved work in docs/MODEL_IMPROVEMENTS.md, with model interfaces
  and validation criteria. Active cooling and reusable leading-edge performance
  must eventually determine the perigee envelope; altitude search bounds do not.
- analysis/primary contains reduced-cycle equations and numerical studies.
  analysis/optimization contains search definitions/results. The Python search
  package is atmo_scoops/optimization; report generators are atmo_scoops/studies.
- analysis/fluid and analysis/stability specify separate offline validation.
  Neither detailed flow nor six-degree-of-freedom simulation belongs inside
  the optimizer. Only explicit, reviewed coefficient maps may feed back.
- Keep vehicle stability distinct from inlet shock stability. Include fluid
  forces/moments, center of mass/inertia, fins, gas motion and thrust alignment.
- Open-mouth port/support coefficients are assumptions, not shock results.
  Keep door mass separate from the permanent bulkhead and report sensitivities.
  Do not silently treat unqualified support as evidence of zero leakage.

## Current documentation and planned studies

- README and docs/DESIGN.md use editable vector sources in docs/images/. Show
  the open-mouth arrangement without a door; retain optional closure in the
  numerical model for the controlled comparison in analysis/primary/MOUTH_CLOSURE.md. Concept drawings are not scale
  layouts or evidence of a selected pump/module count.
- docs/DESIGN_STUDIES_PLAN.md defines the next door and cold-nitrogen-injection
  studies. The closure experiment now has a shared continuous boundary and
  finite-backflow pump envelope; report its results as conditional until inlet
  and pump calibration passes the physical readiness gates. Mixing is planned.
  The general API and 19-variable search still use prescribed inbound capture;
  do not use their perigee-forced closure to select a mouth architecture.
- The atmospheric-column note is generated by
  atmo_scoops.studies.column_physics. Distinguish dynamic q=ρu²/2 from the model's
  ρu² reference, density compression from pressure ratio, and effective column
  V/A from physical chamber depth. Density amplitude cancels at fixed gas state,
  speed, support factor and profile shape; actual perigee changes more than density.
