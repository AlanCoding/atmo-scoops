from dataclasses import replace
import numpy as np
import pytest
from scipy.integrate import solve_ivp
from atmo_scoops.door_trade import FlowCapabilities,DoorControls,net_pump_rate,simulate_trade
from atmo_scoops.system import defaults,inputs_from_dict


def test_finite_pump_backflow_and_analytic_sealed_cutoff():
    V=100.;S=10.;RT=287000.;p0=20.;pu=.3;cutoff=.5
    expected_time=V/S*np.log((p0-pu)/(cutoff-pu))
    sol=solve_ivp(lambda t,p:[-RT/V*net_pump_rate(p[0],S,pu,RT)],
        (0,expected_time),[p0],rtol=1e-10,atol=1e-11)
    assert sol.y[0,-1]==pytest.approx(cutoff,rel=1e-8)
    assert net_pump_rate(pu,S,pu,RT)==0
    assert net_pump_rate(pu/2,S,pu,RT)==0
    assert net_pump_rate(100*pu,S,pu,RT)==pytest.approx(.99*S*100*pu/RT)


def test_continuous_boundary_prefix_is_identical_for_both_architectures():
    inp=inputs_from_dict(defaults());cap=FlowCapabilities();ctl=DoorControls(closure_time_s=100)
    closed=simulate_trade(inp,cap,ctl,n=301,history=True)
    inp['design']=replace(inp['design'],mouth_closure=False)
    opened=simulate_trade(inp,cap,ctl,n=301,history=True)
    t=np.linspace(-350,99,300)
    for field in ('front_Pa','admitted_kg','leaked_kg','rear_kg'):
        # Different event partitions use different interpolation points; compare
        # integrated inventories, not the phase-dependent output-grid indices.
        a=np.interp(t,closed['history']['time_s'],closed['history'][field])
        b=np.interp(t,opened['history']['time_s'],opened['history'][field])
        assert np.allclose(a,b,rtol=2e-3,atol=.003)
    for r in (closed,opened):
        o=r['outputs']
        assert abs(o['captured_kg']-o['retained_kg']-o['vent_kg'])<1e-6
        assert abs(o['thermal_energy_balance_residual_J'])<.01
        assert o['final_front_pressure_Pa']==pytest.approx(ctl.cutoff_Pa,abs=1e-8)
        assert o['pump_stop_reason']=='cutoff_pressure'


def test_unused_door_changes_only_its_mass():
    inp=inputs_from_dict(defaults());ctl=DoorControls(closure_time_s=900)
    closed=simulate_trade(inp,controls=ctl,n=301)
    inp['design']=replace(inp['design'],mouth_closure=False)
    opened=simulate_trade(inp,controls=ctl,n=301)
    a=closed['outputs'];b=opened['outputs']
    for key in ('captured_kg','retained_kg','compressor_kWh','propellant_kg'):
        assert a[key]==pytest.approx(b[key],rel=2e-6)
    assert a['total_dry_kg']-b['total_dry_kg']==pytest.approx(a['masses_kg']['mouth_closure']*1.25,rel=.002)


def test_blocked_air_does_not_disappear_from_momentum_budget():
    inp=inputs_from_dict(defaults())
    r=simulate_trade(inp,n=301)['outputs']
    accounted=r['capture_impulse_Ns']+r['uncollected_mouth_impulse_Ns']
    assert accounted==pytest.approx(r['geometric_intercept_impulse_Ns'],rel=2e-6)
    assert r['uncollected_mouth_impulse_Ns']>0
    expected=(accounted+r['escape_impulse_Ns'])/(inp['design'].isp_s*9.80665)
    assert r['propellant_kg']==pytest.approx(expected)


def test_both_open_and_closed_leakage_and_resolution():
    inp=inputs_from_dict(defaults());inp['design']=replace(inp['design'],front_depth_m=450)
    cap=FlowCapabilities(ultimate_inlet_Pa=1.,closed_leak_area_fraction=.02)
    ctl=DoorControls(closure_time_s=150,cutoff_Pa=1.05,suction_scale=.3)
    for closed in (False,True):
        inp['design']=replace(inp['design'],mouth_closure=closed)
        coarse=simulate_trade(inp,cap,ctl,n=401)
        fine=simulate_trade(inp,cap,ctl,n=1601,history=True)
        a=coarse['outputs'];b=fine['outputs']
        for key in ('captured_kg','retained_kg','total_dry_kg','compressor_kWh'):
            assert a[key]==pytest.approx(b[key],rel=4e-4)
        assert b['mouth_leakage_kg']>0
        assert b['captured_kg']==pytest.approx(b['retained_kg']+b['vent_kg'],abs=1e-6)
        h=fine['history']
        # Transient leakage is resolved by the recorded history too.
        assert np.trapezoid(h['leakage_kg_s'],h['time_s'])==pytest.approx(b['mouth_leakage_kg'],rel=.02)


def test_unreachable_cutoff_and_timeout_are_not_feasible_results():
    inp=inputs_from_dict(defaults())
    with pytest.raises(ValueError,match='Cutoff must exceed'):
        simulate_trade(inp,FlowCapabilities(ultimate_inlet_Pa=1),DoorControls(cutoff_Pa=.1),n=101)
    inp['design']=replace(inp['design'],mouth_closure=False)
    r=simulate_trade(inp,controls=DoorControls(max_after_perigee_s=10),n=101)
    assert not r['constraints']['all_implemented_screens_pass']
    assert r['outputs']['pump_stop_reason']=='time_limit'
